// Handle showing the reservation form
function showReservationForm(packageName) {
    document.getElementById('selectedPackage').value = packageName;
    document.getElementById('reservation-form').classList.remove('hidden');
    // Scroll to the form
    document.getElementById('reservation-form').scrollIntoView({ behavior: 'smooth' });
}

// Handle hiding the reservation form
function hideReservationForm() {
    document.getElementById('reservation-form').classList.add('hidden');
}

// Handle form submission
function submitReservation(event) {
    event.preventDefault();
    
    const formData = {
        package: document.getElementById('selectedPackage').value,
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        message: document.getElementById('message').value
    };

    // Create email content
    const subject = `Scottish Fold Kitten Reservation - ${formData.package}`;
    const body = `
Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Package: ${formData.package}

Additional Message:
${formData.message}
    `.trim();

    // Open email client with pre-filled content
    window.location.href = `mailto:johannajajiga@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    // Clear form and hide it
    document.getElementById('kittenReservationForm').reset();
    hideReservationForm();

    // Show success message
    alert('Thank you for your reservation request! Your email client will open to send the details.');
}